 <!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
  </head>
  <body>
<h1>
<?php
print $_GET['error'];
?>
</h1>
<a href="userPage.php">Naspäť</a>
</body>
</html>

