<?php
header("location: userPage.php");
?>
